#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdlib.h>

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT 27015

unsigned int sleep(unsigned int seconds);

int Meni1() {
	int op;
	system("clear");
	printf("1.) Registruj se\n");
	printf("2.) Loginuj se\n");
	printf("Izaberite opciju: ");
	scanf("%d", &op);
	
	return op;
}

int Meni2() {
	int op;
	system("clear");
	printf("1.) Upload datoteku na server \n");
	printf("2.) Download datoteku sa servera \n");
	printf("3.) Prikazi listu datoteka \n");
	printf("4.) Odjava sa servera \n");
	printf("Izaberite opciju: ");
	scanf("%d", &op);
	
	return op;
}

//////////////////////////////////////// SEND
bool senddata(int sock, void *buf, int buflen)
{
    unsigned char *pbuf = (unsigned char *) buf;

    while (buflen > 0)
    {
        int num = send(sock, pbuf, buflen, 0);

        pbuf += num;
        buflen -= num;
    }

    return true;
}

bool sendlong(int sock, long value)
{
    value = htonl(value);
    return senddata(sock, &value, sizeof(value));
}

bool sendfile(int sock, FILE *f)
{
    fseek(f, 0, SEEK_END);
    long filesize = ftell(f);
    rewind(f);
    if (filesize == EOF)
        return false;
    if(!sendlong(sock, filesize))
        return false;
    if (filesize > 0)
    {
        char buffer[1024];
        do
        {   
            size_t num;
            if(filesize > sizeof(buffer))
                num = sizeof(buffer);
            else
                num = filesize;
            num = fread(buffer, 1, num, f);
            if (num < 1)
                return false;
            if (!senddata(sock, buffer, num))
                return false;
            filesize -= num;
        }
        while (filesize > 0);
    }
    return true;
}
//////////////////////////////////////// READ
bool readdata(int sock, void *buf, int buflen)
{
    unsigned char *pbuf = (unsigned char *) buf;

    while (buflen > 0)
    {
        int num = recv(sock, pbuf, buflen, 0);

        pbuf += num;
        buflen -= num;
    }

    return true;
}

bool readlong(int sock, long *value)
{
    if (!readdata(sock, value, sizeof(value)))
        return false;
    *value = ntohl(*value);
    return true;
}

bool readfile(int sock, FILE *f)
{
    long filesize;
    if (!readlong(sock, &filesize))
        return false;
    if (filesize > 0)
    {
        char buffer[1024];
        do
        {
            int num;
            if(filesize > sizeof(buffer))
                num = sizeof(buffer);
            else
                num = filesize;
                
            if (!readdata(sock, buffer, num))
                return false;
            int offset = 0;
            do
            {
                size_t written = fwrite(&buffer[offset], 1, num-offset, f);
                if (written < 1)
                    return false;
                offset += written;
            }
            while (offset < num);
            filesize -= num;
        }
        while (filesize > 0);
    }
    return true;
}

int main(int argc , char *argv[])
{
	int sock;
	struct sockaddr_in server;
	///////////////
	char username[DEFAULT_BUFLEN];
	char password[10];
	int opcija;
	int flagreg = -1;
	int flaglog = -1;
    
    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");

    server.sin_addr.s_addr = inet_addr("10.81.30.42");
    server.sin_family = AF_INET;
    server.sin_port = htons(DEFAULT_PORT);

    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
        return 1;
    }
    puts("Connected\n");
    
    while(1) {
		
		opcija = Meni1();
		send(sock, &opcija, sizeof(opcija), 0);
		switch(opcija) {
			case 1 :
				system("clear");
				printf("* Registracija *\n");
				printf("Unesite username: ");
				scanf("%s", username);
				if(send(sock, username, strlen(username), 0) < 0) {
					printf("Klijent: neuspesno slanje");
					return 1;
				} 
				printf("Unesite password: ");
				scanf("%s", password);
				if(send(sock, password, strlen(password), 0) < 0) {
					printf("Klijent: neuspesno slanje");
					return 1;
				}
				recv(sock, &flagreg, sizeof(flagreg), 0);
				printf("OK\n");
				break;
			case 2 :
				system("clear");
				printf("* Login *\n");
				printf("Unesite username: ");
				scanf("%s", username);
				if(send(sock, username, strlen(username), 0) < 0) {
					printf("Klijent: neuspesno slanje");
					return 1;
				}
				printf("Unesite password: ");
				scanf("%s", password);
				if(send(sock, password, strlen(password), 0) < 0) {
					printf("Klijent: neuspesno slanje");
					return 1;
				}
				recv(sock, &flaglog, sizeof(flaglog), 0);
				printf("OK\n");
				break;
			default :			
				printf("Pogresna opcija\n");
				sleep(1);
				break;
		}		
		sleep(3);
		system("clear");
		if(flagreg == 0)
			break;
		else if(flaglog == 0)
			break;
	}
    int flagwrite = -1;
    int flagread = -1;
    FILE *fp;
    char ime[DEFAULT_BUFLEN];
    char lista[DEFAULT_BUFLEN];
    
    while(1) {
		
		opcija = Meni2();
		send(sock, &opcija, sizeof(opcija), 0);
		switch(opcija) {
			case 1 :
				system("clear");
				printf("Unesite puno ime datoteke: ");
				scanf("%s", ime);
				send(sock, ime, strlen(ime), 0);
        
				recv(sock, &flagwrite, sizeof(flagwrite), 0);
				if(flagwrite == 0) {
					fp = fopen(ime, "rb");
					sendfile(sock, fp);
					fclose(fp); 
					printf("Uspesno upisana datoteka u listu\n");
				}
				else
					printf("Datoteka sa istim imenom vec postoji\n");
				sleep(2);
				break;
			case 2 :
				system("clear");
				printf("Unesite puno ime datoteke: ");
				scanf("%s", ime);
				send(sock, ime, strlen(ime), 0);
        
				recv(sock, &flagread, sizeof(flagread), 0);
				if(flagread == 0) {
					fp = fopen(ime, "wb");
					readfile(sock, fp);
					fclose(fp);
					printf("Uspesno preuzeta datoteka\n");
				}
				else
					printf("Neuspesno preuzimanje datoteke\n");
				sleep(2);
				break;
			case 3 :
				system("clear");
				printf("LISTA\n");
				int read_size = recv(sock, lista, DEFAULT_BUFLEN, 0);
				lista[read_size] = '\0';
				printf("%s", lista);
				sleep(2);
				break;
			case 4 :
				system("clear");
				printf("Uspesno ste odjavljeni sa servera\n");
				sleep(1);
				break;
			default :
				printf("Pogresna opcija\n");
				sleep(1);
				break;
		}
		if(opcija == 4)
			break;
	}

    close(sock);

    return 0;
}

