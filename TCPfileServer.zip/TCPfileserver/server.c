#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <semaphore.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT 27015
#define NUMBER_OF_CLIENTS 4

typedef struct hParameter_long //struktura u koju smestamo redni broj korisnika i socket
{
	int Number;
	int Socket;
}hParameter;

pthread_t hClient[NUMBER_OF_CLIENTS]; //niz niti
static pthread_mutex_t mutex;
static sem_t semafor;
int broj[10];

int Register(FILE *fp, char *ime, char *sifra) {
	char time[DEFAULT_BUFLEN];
	char tsifra[DEFAULT_BUFLEN];
	int flag = 0;
	while(fscanf(fp, "%s %s", time, tsifra) == 2) {
		if(strcmp(ime, time) == 0) {
			flag = 1;	// Zauzeto ime
			printf("Korisnik sa imenom: '%s' vec postoji\n", ime);
			break;
		}
	}
	if(flag == 0) {	// Presao celu bazu i nema istog imena
		fprintf(fp, "\n%s %s", ime, sifra);
		printf("Korisnik uspesno registrovan\n");
	}
	return flag;
}

int Login(FILE *fp, char *ime, char *sifra) {
	char time[DEFAULT_BUFLEN];
	char tsifra[DEFAULT_BUFLEN];
	int flag = 2;
	while(fscanf(fp, "%s %s", time, tsifra) == 2) {
		if(strcmp(ime, time) == 0) {
			if(strcmp(sifra, tsifra) == 0) {
				flag = 0;
				printf("Korsnik uspesno logovan\n");
				break;	// Korisnik pronadjen -login
			}
			else {
				printf("Pogresna sifra\n");
				flag = 1;
				break;
			}
		}
	}
	if(flag == 2)
		printf("Nepostojeci username\n");
	return flag;
}

char* List(FILE *fp) {
    char data[DEFAULT_BUFLEN];
    char *lista = NULL;
    long filesize = ftell(fp);
    lista = malloc(filesize);
    while(fscanf(fp, "%s", data) == 1) {
        strcat(lista, data);
        strcat(lista, "\n");
	printf("Fja: %s", lista);
    }
    
    return lista;
}

int WriteList(FILE *fp, char *data) {
    int flag = 0;
    char ime[DEFAULT_BUFLEN];
    while(fscanf(fp, "%s", ime) != EOF) {
        if(strcmp(ime, data) == 0) {
            flag = 1;
            printf("Datoteka sa istim imenom vec postoji\n");
            break;
        }
    }
    if(flag == 0) {
        fprintf(fp, "%s\n", data);
        printf("Uspesno upisana datoteka u listu\n");
    }
    return flag;
}

int ReadList(FILE *fp, char *data) {
    int flag = 0;
    char ime[DEFAULT_BUFLEN];
    while(fscanf(fp, "%s", ime) != EOF) {
        if(strcmp(ime, data) == 0) {
            printf("Datoteka postoji, OK\n");
            break;
        }
        flag = 1;
    }
    return flag;
}

//////////////////////////////////////// READ
bool readdata(int sock, void *buf, int buflen)
{
    unsigned char *pbuf = (unsigned char *) buf;

    while (buflen > 0)
    {
        int num = recv(sock, pbuf, buflen, 0);

        pbuf += num;
        buflen -= num;
    }

    return true;
}

bool readlong(int sock, long *value)
{
    if (!readdata(sock, value, sizeof(value)))
        return false;
    *value = ntohl(*value);
    return true;
}

bool readfile(int sock, FILE *f)
{
    long filesize;
    if (!readlong(sock, &filesize))
        return false;
    if (filesize > 0)
    {
        char buffer[1024];
        do
        {
            int num;
            if(filesize > sizeof(buffer))
                num = sizeof(buffer);
            else
                num = filesize;
                
            if (!readdata(sock, buffer, num))
                return false;
            int offset = 0;
            do
            {
                size_t written = fwrite(&buffer[offset], 1, num-offset, f);
                if (written < 1)
                    return false;
                offset += written;
            }
            while (offset < num);
            filesize -= num;
        }
        while (filesize > 0);
    }
    return true;
}
//////////////////////////////////////// SEND
bool senddata(int sock, void *buf, int buflen)
{
    unsigned char *pbuf = (unsigned char *) buf;

    while (buflen > 0)
    {
        int num = send(sock, pbuf, buflen, 0);

        pbuf += num;
        buflen -= num;
    }

    return true;
}

bool sendlong(int sock, long value)
{
    value = htonl(value);
    return senddata(sock, &value, sizeof(value));
}

bool sendfile(int sock, FILE *f)
{
    fseek(f, 0, SEEK_END);
    long filesize = ftell(f);
    rewind(f);
    if (filesize == EOF)
        return false;
    if(!sendlong(sock, filesize))
        return false;
    if (filesize > 0)
    {
        char buffer[1024];
        do
        {   
            size_t num;
            if(filesize > sizeof(buffer))
                num = sizeof(buffer);
            else
                num = filesize;
            num = fread(buffer, 1, num, f);
            if (num < 1)
                return false;
            if (!senddata(sock, buffer, num))
                return false;
            filesize -= num;
        }
        while (filesize > 0);
    }
    return true;
}

void* Fun(void* param) //ovo je funkcija koja cini nit, tj ovo je funkcija koja opsluzuje klijenta, prvo pogledaj main
{
	hParameter *temp = (hParameter*) param; //kastujemo parametar funkcije u strukturu
	int i = temp->Number; //izvlacimo redni broj korisnika(cija je ovo nit) iz strukture
	int clientSocket = temp->Socket; //izvlacimo socket korisnika(cija je ovo nit) iz strukture
	
	int read_size;
	sem_post(&semafor); //semafor nam treba jer radimo sa jednom strukturom,pa nakon sto smo izvukli sve sto nam treba iz strukture javljamo sledecoj niti da moze da prepise nove podatke preko starih
	/////////////////////////////
	char ime[DEFAULT_BUFLEN];
	char sifra[10];
	FILE *fp;
	int flagreg = -1;
	int flaglog = -1;
	int opcija;
	
	while(1) {
		
		recv(clientSocket, &opcija, sizeof(opcija), 0);
		printf("[%d] - Opcija: %d\n", i, opcija);	
		
		read_size = recv(clientSocket, ime, DEFAULT_BUFLEN, 0);
		ime[read_size] = '\0'; 
		printf("[%d] - Ime: %s\n", i, ime);
	
		read_size = recv(clientSocket, sifra, DEFAULT_BUFLEN, 0);
		sifra[read_size] = '\0'; 
		printf("[%d] - Sifra: %s\n", i, sifra);
		
		switch(opcija) {
			case 1 :
				fp = fopen("baza.txt", "r+");
				flagreg = Register(fp, ime, sifra);
				fclose(fp);
				printf("Flagreg : %d\n", flagreg);
				send(clientSocket, &flagreg, sizeof(flagreg), 0);
				break;
			case 2 :				
				fp = fopen("baza.txt", "r");
				flaglog = Login(fp, ime, sifra);
				fclose(fp);
				printf("Flaglog: %d\n", flaglog);
				send(clientSocket, &flaglog, sizeof(flaglog), 0);			
				break;
		}
		
		if(flagreg == 0)
			break;
		else if(flaglog == 0)
			break;			
	}
	//////////////////
	char ime1[DEFAULT_BUFLEN];
	char ime2[DEFAULT_BUFLEN] = "../";
	char *lista; 
	int opcija2;
	int flagwrite = -1;
	int flagread = -1;
	FILE *fplist, *fp1;
	
	while(1) {
		
		recv(clientSocket, &opcija2, sizeof(opcija2), 0);
		printf("[%d] - Opcija2: %d\n", i, opcija2);
		
		switch(opcija2) {
			case 1 : 
				read_size = recv(clientSocket, ime1, DEFAULT_BUFLEN, 0);
				ime[read_size] = '\0';
				printf("Ime: %s\n", ime1);
				strcat(ime2, ime1);
				
				fplist = fopen("lista.txt", "r+");
				flagwrite = WriteList(fplist, ime1);
				fclose(fplist);
				send(clientSocket, &flagwrite, sizeof(flagwrite), 0);
				if(flagwrite == 0) {
					fp1 = fopen(ime2, "wb");
					if(fp1 != NULL) {
						readfile(clientSocket, fp1);
					fclose(fp1);
					}
				}
				break;
			case 2 : 
				read_size = recv(clientSocket, ime1, DEFAULT_BUFLEN, 0);
				ime[read_size] = '\0';
				printf("Ime: %s\n", ime1);
				strcat(ime2, ime1);
        
				fplist = fopen("lista.txt", "r");
				flagread = ReadList(fplist, ime1);
				fclose(fplist);
				send(clientSocket, &flagread, sizeof(flagread), 0);
				if(flagread == 0) {

					fp = fopen(ime2, "rb");
					sendfile(clientSocket, fp);
					fclose(fp);
				}
				break;
			case 3 :
				fplist = fopen("lista.txt", "r");
				lista = List(fplist);				
				printf("Main: %s", lista);
				send(clientSocket, lista, strlen(lista), 0);
				fclose(fplist);
				printf("Posle zatvaranja");
				break;	
			case 4 : 
				printf("Logout\n");
				break;
		}
		
		if(opcija2 == 4)
			break;
	}

	puts("DONE");
}


int main(int argc , char *argv[])
{
    int socket_desc , client_sock[10] , c;
    struct sockaddr_in server , client[10];
    hParameter structure; //struktura u kojoj cemo da pakujemo redni broj korisnika i njegov socket u nit(da prosledimo kao parametar "funk" funkciji tj niti)
    sem_init(&semafor, 0, 1); //semafor nam treba jer koristimo samo jednu strukturu(moglo je da se resi i bez semafora ako koristimo niz struktura)
    pthread_mutex_init(&mutex, NULL); //mutex koristi da stitis podatke ako ih dele vise niti
	
    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0); //TCP socket na kojem slusamo
    if (socket_desc == -1)
    {
        printf("Server: Problem kod pravljenja soketa.\n");
    }
    puts("Server: Soket napravljen.");

    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(DEFAULT_PORT);

    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0) {
        printf("Server: Neuspesno bindovanje.\n");
        return 1;
    }
    puts("Server: Bindovanje uspesno.");

    //Listen
    listen(socket_desc , 2); //ceka da 2 korisnika zatraze da se povezu

    puts("Server: Cekam na konekciju klijenata...\n");
    c = sizeof(struct sockaddr_in);

	int i = 0;

    while(client_sock[i] = accept(socket_desc, (struct sockaddr *)(client+i), (socklen_t*)&c)) //prihvatamo zahteve korisnika da se povezu
    {
    	if (client_sock[i] < 0) //nije uspostavljena konekcija
    	{
    	    perror("accept failed");
    	    return 1;
    	}
    	printf("Konekcija sa klijentom:%d uspostavljena.\n", i);
    	sem_wait(&semafor); //main nit treba da saceka da funk funkcija izvuce potrebne podatke(npr ako main nit uradi jednu iteraciju(dodje do kraja while i pocne ponovo) pre nego sto funk funkcija izvuce podatke
    	structure.Number = i; //pakujemo redni broj korisnika u strukturu
    	structure.Socket = client_sock[i]; //pakujemo odgovarajuci socket u strukturu
    	//printf("%d, %d", structure.Number, structure.Socket);
		pthread_create(&hClient[i], NULL, Fun, (void*)&structure); //pravimo nit koja ce da pokrene funkciju "funk" koja kao parametar prima "structure", pogledaj gore FUNK
		printf("Thread %d created\n", i);
		i++;//povecavamo redni broj korisnika

		if(i == 2) //kada se povezu dva korisnika treba da izadjemo iz while petlje		
			break;
    }
    
	int l = 0;
	for(l = 0;l<i;l++)
		pthread_join(hClient[l], NULL); //joinamo niti, tj govorimo main funkciji da mora da saceka da FUNK funkcija od svakog korisnika mora da zavrsi sa radom pre nego sto joj je dozvoljeno da nastavi
	
	int brojac = 0; //pravimo brojac koji nam govori koliko je socketa uspesno zatvoreno
	for(l = 0;l<i;l++)
		if(close(client_sock[l]) == 0) //zatvaramo socket, ako vrati nula onda je sve ok
			brojac++; //povecavamo brojac uspesno zatvorenih socketa
	
	if(brojac == i) //ako je brojac jednak broju klijenata onda su svi socketi uspesno zatvoreni
		printf("Server: Konekcija sa svim korisnicima je zavrsena.\n");
	else //ako nije onda neki ili svi socketi nisu uspesno zatvoreni
		perror("Server: Greska kod zatvaranje soketa.\n");
		
	sem_destroy(&semafor); //unistavamo semafor
	pthread_mutex_destroy(&mutex); //unistavamo mutex
	
    return 0;
}

